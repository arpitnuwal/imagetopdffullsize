﻿using System.Drawing;
using System.Drawing.Imaging;

public class ImageResizer
{
    public static Image ResizeImage(Image image, int targetWidth, int targetHeight)
    {
        int width, height;

        // Calculate aspect ratio
        double aspectRatio = (double)image.Width / image.Height;

        // Check if width or height needs to be adjusted based on aspect ratio
        if (aspectRatio > 1)
        {
            // Landscape orientation
            width = targetWidth;
            height = (int)(targetWidth / aspectRatio);
        }
        else
        {
            // Portrait or square orientation
            height = targetHeight;
            width = (int)(targetHeight * aspectRatio);
        }

        // Create new bitmap with adjusted dimensions
        Bitmap resizedImage = new Bitmap(width, height);

        // Use Graphics to draw the resized image from the original image
        using (Graphics graphics = Graphics.FromImage(resizedImage))
        {
            graphics.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
            graphics.DrawImage(image, 0, 0, width, height);
        }

        return resizedImage;
    }
}

// Usage example:

